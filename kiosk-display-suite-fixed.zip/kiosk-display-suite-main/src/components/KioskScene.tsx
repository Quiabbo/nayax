/**
 * KIOSK 3D SCENE COMPONENT
 * 
 * Main Three.js canvas containing the kiosk, screen, card, and interactions.
 * 
 * ADJUSTABLE VARIABLES:
 * - CAMERA_POS_MULTIPLIER: Multiplier for camera position based on model size
 * - CAMERA_FOV: Field of view for the camera
 * - CONTROLS_MIN_DISTANCE: Minimum zoom distance
 * - CONTROLS_MAX_DISTANCE: Maximum zoom distance
 */

import { Canvas } from "@react-three/fiber";
import { OrbitControls, Environment } from "@react-three/drei";
import { Suspense, useState, useCallback, useRef, useEffect } from "react";
import { useThree } from "@react-three/fiber";
import * as THREE from "three";
import KioskModel, { ModelBounds } from "./KioskModel";
import KioskScreen, { ScreenState } from "./KioskScreen";
import CreditCard from "./CreditCard";
import CardReaderHotspot from "./CardReaderHotspot";
import SceneLighting from "./SceneLighting";
import { useBeepSound } from "@/hooks/useBeepSound";

// ============ ADJUSTABLE VARIABLES ============
const CAMERA_FOV = 45;
const CAMERA_POS_MULTIPLIER = { y: 0.8, z: 2.2 };
const CONTROLS_MIN_DISTANCE = 3;
const CONTROLS_MAX_DISTANCE = 12;
// ==============================================

const LoadingFallback = () => (
  <mesh>
    <boxGeometry args={[1, 1, 1]} />
    <meshStandardMaterial color="#FACA08" />
  </mesh>
);

interface SceneContentProps {
  screenState: ScreenState;
  onStateChange: (state: ScreenState) => void;
  cardPosition: THREE.Vector3 | null;
  setCardPosition: (pos: THREE.Vector3 | null) => void;
  isCardDragging: boolean;
  setIsCardDragging: (dragging: boolean) => void;
  onCardDetected: () => void;
  onCameraReady: (camera: THREE.Camera) => void;
}

const SceneContent = ({
  screenState,
  onStateChange,
  cardPosition,
  setCardPosition,
  isCardDragging,
  setIsCardDragging,
  onCardDetected,
  onCameraReady
}: SceneContentProps) => {
  const controlsRef = useRef<any>(null);
  const [modelBounds, setModelBounds] = useState<ModelBounds | null>(null);
  const [layout, setLayout] = useState<{
    cameraPos: [number, number, number];
    target: [number, number, number];
    screenPos: [number, number, number];
    screenSize: [number, number];
    cardStartPos: [number, number, number];
    hotspotPos: [number, number, number];
  } | null>(null);
  const { camera } = useThree();

  useEffect(() => {
    onCameraReady(camera);
  }, [camera, onCameraReady]);

  const handleModelLoad = useCallback((bounds: ModelBounds) => {
    const maxDim = Math.max(bounds.size.x, bounds.size.y, bounds.size.z);

    // Derived positions based on model size (keeps everything centered and visible)
    const target: [number, number, number] = [0, bounds.size.y * 0.55, 0];
    const cameraPos: [number, number, number] = [0, bounds.size.y * 0.8, maxDim * 2.8];

    // Screen plane roughly where the display usually is (tweakable later)
    const screenPos: [number, number, number] = [0, bounds.size.y * 0.78, bounds.size.z * 0.22];
    const screenSize: [number, number] = [Math.max(0.35, bounds.size.x * 0.32), Math.max(0.55, bounds.size.y * 0.42)];

    // Card starts to the right, with breathing room
    const cardStartPos: [number, number, number] = [bounds.size.x * 0.95, bounds.size.y * 0.72, maxDim * 0.55];

    // Reader hotspot (front-right area)
    const hotspotPos: [number, number, number] = [bounds.size.x * 0.25, bounds.size.y * 0.48, bounds.size.z * 0.45];

    if (controlsRef.current) {
      controlsRef.current.target.set(...target);
      controlsRef.current.update();
    }

    setLayout({ cameraPos, target, screenPos, screenSize, cardStartPos, hotspotPos });
    setModelBounds(bounds);
  }, []);

  useEffect(() => {
    if (modelBounds && camera) {
      // Position camera based on derived layout (centered + closer)
      const cam = layout?.cameraPos ?? [0, modelBounds.size.y * CAMERA_POS_MULTIPLIER.y, modelBounds.size.z * CAMERA_POS_MULTIPLIER.z];
      const tgt = layout?.target ?? [0, modelBounds.size.y * 0.5, 0];

      camera.position.set(cam[0], cam[1], cam[2]);
      camera.lookAt(tgt[0], tgt[1], tgt[2]);
      if (controlsRef.current) {
        controlsRef.current.update();
      }
    }
  }, [modelBounds, camera, layout]);

  return (
    <>
      {/* Lighting */}
      <SceneLighting />
      
      {/* Environment for reflections */}
      <Environment preset="city" />
      
      {/* Kiosk model */}
      <KioskModel onLoad={handleModelLoad}>
        {/* Interactive screen attached to model */}
        <KioskScreen 
          screenState={screenState} 
          onStateChange={onStateChange}
          screenPos={layout?.screenPos}
          screenSize={layout?.screenSize}
          htmlScale={2.2}
          htmlDistanceFactor={1.8}
          htmlSize={[620, 860]}
        />
        
        {/* Card reader detection hotspot attached to model */}
        <CardReaderHotspot 
          cardPosition={cardPosition}
          isCardDragging={isCardDragging}
          onCardDetected={onCardDetected}
          isActive={screenState === "payment"}
          hotspotPos={layout?.hotspotPos}
        />
      </KioskModel>
      
      {/* Draggable credit card */}
      <CreditCard 
        startPosition={layout?.cardStartPos}
        onPositionChange={setCardPosition}
        isDragging={isCardDragging}
        setIsDragging={setIsCardDragging}
      />
      
      {/* Floor plane */}
      <mesh 
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, 0, 0]}
        receiveShadow
      >
        <planeGeometry args={[20, 20]} />
        <meshStandardMaterial 
          color="hsl(0 0% 93%)"
          roughness={0.8}
        />
      </mesh>
      
      {/* Camera controls */}
      <OrbitControls 
        ref={controlsRef}
        enablePan={false}
        enableZoom={true}
        enableRotate={true}
        minDistance={Math.max(1.5, (modelBounds?.size ? Math.max(modelBounds.size.x, modelBounds.size.y, modelBounds.size.z) : CONTROLS_MIN_DISTANCE) * 1.2)}
        maxDistance={Math.max(8, (modelBounds?.size ? Math.max(modelBounds.size.x, modelBounds.size.y, modelBounds.size.z) : CONTROLS_MAX_DISTANCE) * 5)}
        minPolarAngle={0.2}
        maxPolarAngle={Math.PI / 2 - 0.1}
        enabled={!isCardDragging}
      />
    </>
  );
};

const KioskScene = () => {
  const [screenState, setScreenState] = useState<ScreenState>("welcome");
  const [cardPosition, setCardPosition] = useState<THREE.Vector3 | null>(null);
  const [isCardDragging, setIsCardDragging] = useState(false);
  const { playBeep } = useBeepSound();
  const processingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const cameraRef = useRef<THREE.Camera | null>(null);

  const handleCameraReady = useCallback((camera: THREE.Camera) => {
    cameraRef.current = camera;
  }, []);

  const handleCardDetected = useCallback(() => {
    if (screenState !== "payment") return;
    
    // Play beep sound
    playBeep();
    
    // Show processing state
    setScreenState("processing");
    
    // Clear any existing timeout
    if (processingTimeoutRef.current) {
      clearTimeout(processingTimeoutRef.current);
    }
    
    // After 1.5s, show success
    processingTimeoutRef.current = setTimeout(() => {
      setScreenState("success");
    }, 1500);
  }, [screenState, playBeep]);

  const handleScreenStateChange = useCallback((state: ScreenState) => {
    // Clear processing timeout if user navigates away
    if (processingTimeoutRef.current) {
      clearTimeout(processingTimeoutRef.current);
    }
    setScreenState(state);
  }, []);

  return (
    <div className="w-full h-[calc(100vh-4rem)]">
      <Canvas
        shadows
        camera={{ 
          position: [0, 3, 8], 
          fov: CAMERA_FOV,
          near: 0.1,
          far: 100
        }}
        gl={{ antialias: true }}
      >
        <color attach="background" args={['hsl(0 0% 93%)']} />
        
        <Suspense fallback={<LoadingFallback />}>
          <SceneContent
            screenState={screenState}
            onStateChange={handleScreenStateChange}
            cardPosition={cardPosition}
            setCardPosition={setCardPosition}
            isCardDragging={isCardDragging}
            setIsCardDragging={setIsCardDragging}
            onCardDetected={handleCardDetected}
            onCameraReady={handleCameraReady}
          />
        </Suspense>
      </Canvas>
    </div>
  );
};

export default KioskScene;
