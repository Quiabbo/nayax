/**
 * CREDIT CARD 3D COMPONENT
 * 
 * A draggable purple credit card (Nubank style) that can be moved in 3D space.
 * 
 * ADJUSTABLE VARIABLES:
 * - CARD_START_POS: Initial [x, y, z] position of the card
 * - CARD_SIZE: [width, height, depth] dimensions
 */

import { useRef, useState, useEffect } from "react";
import { useFrame, useThree, type ThreeEvent } from "@react-three/fiber";
import { Html } from "@react-three/drei";
import * as THREE from "three";

// ============ ADJUSTABLE VARIABLES ============
export const CARD_START_POS: [number, number, number] = [3.5, 2.0, 1.5];
const CARD_SIZE: [number, number, number] = [0.85, 0.54, 0.02];
// ==============================================

interface CreditCardProps {
  startPosition?: [number, number, number];
  onPositionChange: (position: THREE.Vector3) => void;
  isDragging: boolean;
  setIsDragging: (dragging: boolean) => void;
}

const CreditCard = ({ startPosition, onPositionChange, isDragging, setIsDragging }: CreditCardProps) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const { camera, gl } = useThree();
  
  const basePos = useRef(new THREE.Vector3(...(startPosition ?? CARD_START_POS)));
  const dragPlane = useRef(new THREE.Plane());
  const dragOffset = useRef(new THREE.Vector3());
  const intersection = useRef(new THREE.Vector3());

  useEffect(() => {
    basePos.current.set(...(startPosition ?? CARD_START_POS));
    if (meshRef.current && !isDragging) {
      meshRef.current.position.copy(basePos.current);
    }
  }, [startPosition, isDragging]);

  useEffect(() => {
    if (hovered || isDragging) {
      gl.domElement.style.cursor = isDragging ? 'grabbing' : 'grab';
    } else {
      gl.domElement.style.cursor = 'auto';
    }
  }, [hovered, isDragging, gl.domElement]);

  useFrame(() => {
    if (meshRef.current) {
      // Gentle floating animation when not dragging
      if (!isDragging) {
        meshRef.current.position.y = basePos.current.y + Math.sin(Date.now() * 0.002) * 0.05;
        meshRef.current.rotation.y = Math.sin(Date.now() * 0.001) * 0.1;
      }
      onPositionChange(meshRef.current.position);
    }
  });

  const handlePointerDown = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    (e.target as unknown as Element).setPointerCapture?.(e.pointerId);
    setIsDragging(true);
    
    if (meshRef.current) {
      // Set up drag plane facing camera
      const cameraDirection = new THREE.Vector3();
      camera.getWorldDirection(cameraDirection);
      dragPlane.current.setFromNormalAndCoplanarPoint(cameraDirection.negate(), meshRef.current.position);

      // Calculate offset using r3f event ray (canvas-relative)
      const hit = e.ray.intersectPlane(dragPlane.current, intersection.current);
      if (hit) {
        dragOffset.current.subVectors(meshRef.current.position, intersection.current);
      }
    }
  };

  const handlePointerMove = (e: ThreeEvent<PointerEvent>) => {
    if (!isDragging || !meshRef.current) return;
    e.stopPropagation();
    
    const hit = e.ray.intersectPlane(dragPlane.current, intersection.current);
    if (hit) {
      meshRef.current.position.copy(intersection.current.add(dragOffset.current));
    }
  };

  const handlePointerUp = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    (e.target as unknown as Element).releasePointerCapture?.(e.pointerId);
    setIsDragging(false);
  };

  return (
    <mesh
      ref={meshRef}
      position={startPosition ?? CARD_START_POS}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => {
        setHovered(false);
        if (!isDragging) setIsDragging(false);
      }}
      onPointerLeave={(e) => handlePointerUp(e)}
      castShadow
    >
      {/* Card body */}
      <boxGeometry args={CARD_SIZE} />
      <meshStandardMaterial 
        color="hsl(280 96% 38%)"
        metalness={0.3}
        roughness={0.4}
        emissive={hovered || isDragging ? "hsl(280 96% 38%)" : "hsl(0 0% 0%)"}
        emissiveIntensity={hovered || isDragging ? 0.2 : 0}
      />
      
      {/* Card details overlay */}
      <Html
        transform
        position={[0, 0, 0.015]}
        style={{
          width: '170px',
          height: '108px',
          pointerEvents: 'none',
          userSelect: 'none',
        }}
      >
        <div 
          className="w-full h-full p-3 flex flex-col justify-between bg-brand-purple"
          style={{ borderRadius: '8px', fontFamily: 'monospace' }}
        >
          {/* Chip */}
          <div 
            className="w-8 h-6 rounded"
            style={{ background: 'hsl(47 97% 50%)' }}
          />
          
          {/* Card number */}
          <div className="text-xs tracking-wider opacity-80 text-white">
            •••• •••• •••• 4242
          </div>
          
          {/* Card holder */}
          <div className="flex justify-between items-end">
            <div>
              <div className="text-[8px] opacity-60 text-white">TITULAR</div>
              <div className="text-[10px] text-white">DEMO USER</div>
            </div>
            <div className="text-right">
              <div className="text-[8px] opacity-60 text-white">VALIDADE</div>
              <div className="text-[10px] text-white">12/28</div>
            </div>
          </div>
        </div>
      </Html>
    </mesh>
  );
};

export default CreditCard;
