/**
 * CARD READER HOTSPOT COMPONENT
 * 
 * An invisible detection zone near the kiosk's card reader.
 * When the credit card enters this zone, it triggers the payment flow.
 * 
 * ADJUSTABLE VARIABLES:
 * - HOTSPOT_POS: [x, y, z] position of the hotspot
 * - HOTSPOT_SIZE: Size of the detection sphere
 * - DETECTION_DISTANCE: How close the card needs to be to trigger
 */

import { useRef, useEffect, useState } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

// ============ ADJUSTABLE VARIABLES ============
export const HOTSPOT_POS: [number, number, number] = [0.65, 1.2, 0.7];
const HOTSPOT_SIZE = 0.35;
export const DETECTION_DISTANCE = 0.6;
// ==============================================

interface CardReaderHotspotProps {
  cardPosition: THREE.Vector3 | null;
  isCardDragging: boolean;
  onCardDetected: () => void;
  isActive: boolean;
  hotspotPos?: [number, number, number];
}

const CardReaderHotspot = ({
  cardPosition,
  isCardDragging,
  onCardDetected,
  isActive,
  hotspotPos,
}: CardReaderHotspotProps) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const [isNear, setIsNear] = useState(false);
  const [glowIntensity, setGlowIntensity] = useState(0);
  const hasTriggered = useRef(false);

  // Reset trigger when not active
  useEffect(() => {
    if (!isActive) {
      hasTriggered.current = false;
    }
  }, [isActive]);

  useFrame(() => {
    if (!cardPosition || !meshRef.current || !isActive) {
      setIsNear(false);
      setGlowIntensity(0);
      return;
    }

    const hotspotVec = new THREE.Vector3(...(hotspotPos ?? HOTSPOT_POS));
    const distance = cardPosition.distanceTo(hotspotVec);
    
    // Check if card is near
    const near = distance < DETECTION_DISTANCE;
    setIsNear(near);
    
    // Animate glow based on distance
    const intensity = Math.max(0, 1 - distance / DETECTION_DISTANCE);
    setGlowIntensity(intensity);

    // Trigger detection when card is released in the hotspot
    if (near && !isCardDragging && !hasTriggered.current) {
      hasTriggered.current = true;
      onCardDetected();
    }
  });

  if (!isActive) return null;

  return (
    <group position={hotspotPos ?? HOTSPOT_POS}>
      {/* Invisible detection sphere */}
      <mesh ref={meshRef}>
        <sphereGeometry args={[HOTSPOT_SIZE, 16, 16]} />
        <meshBasicMaterial 
          color="hsl(47 97% 50%)"
          transparent
          opacity={isNear ? 0.3 : 0.15}
          depthWrite={false}
        />
      </mesh>
      
      {/* Glow ring indicator */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <ringGeometry args={[HOTSPOT_SIZE * 0.8, HOTSPOT_SIZE, 32]} />
        <meshBasicMaterial 
          color="hsl(47 97% 50%)"
          transparent
          opacity={glowIntensity * 0.8}
          side={THREE.DoubleSide}
        />
      </mesh>
      
      {/* Pulsing outer ring when near */}
      {isNear && (
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <ringGeometry args={[HOTSPOT_SIZE, HOTSPOT_SIZE * 1.5, 32]} />
          <meshBasicMaterial 
            color="hsl(47 97% 50%)"
            transparent
            opacity={0.2 + Math.sin(Date.now() * 0.01) * 0.1}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}
    </group>
  );
};

export default CardReaderHotspot;
