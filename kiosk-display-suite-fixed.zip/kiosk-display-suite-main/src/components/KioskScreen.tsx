/**
 * KIOSK SCREEN COMPONENT
 * 
 * A PlaneGeometry positioned on the kiosk that displays interactive content.
 * Uses Html from drei to render React content on the 3D plane.
 * 
 * ADJUSTABLE VARIABLES:
 * - SCREEN_POS: [x, y, z] position of the screen relative to model
 * - SCREEN_ROT: [x, y, z] rotation in radians
 * - SCREEN_SIZE: [width, height] of the screen plane
 * - HTML_SCALE: Scale factor for the HTML overlay
 * - HTML_DISTANCE_FACTOR: Distance factor for Html component
 * - HTML_SIZE: [width, height] in pixels for the HTML content
 */

import { Html } from "@react-three/drei";
import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";

// ============ ADJUSTABLE VARIABLES ============
export const SCREEN_POS: [number, number, number] = [0, 2.8, 0.52];
export const SCREEN_ROT: [number, number, number] = [0, 0, 0];
export const SCREEN_SIZE: [number, number] = [1.6, 2.4];
export const HTML_SCALE = 1.9;
export const HTML_DISTANCE_FACTOR = 1.8;
export const HTML_SIZE: [number, number] = [520, 760];
// ==============================================

export type ScreenState = "welcome" | "options" | "payment" | "processing" | "success";

interface KioskScreenProps {
  screenState: ScreenState;
  onStateChange: (state: ScreenState) => void;
  screenPos?: [number, number, number];
  screenRot?: [number, number, number];
  screenSize?: [number, number];
  htmlScale?: number;
  htmlDistanceFactor?: number;
  htmlSize?: [number, number];
}

const KioskScreen = ({ screenState, onStateChange, screenPos, screenRot, screenSize, htmlScale, htmlDistanceFactor, htmlSize }: KioskScreenProps) => {
  const [isHovered, setIsHovered] = useState(false);

  const handleStart = useCallback(() => {
    onStateChange("options");
  }, [onStateChange]);

  const handlePayment = useCallback(() => {
    onStateChange("payment");
  }, [onStateChange]);

  const handleBack = useCallback(() => {
    onStateChange("welcome");
  }, [onStateChange]);

  const renderContent = () => {
    switch (screenState) {
      case "welcome":
        return (
          <div className="flex flex-col items-center justify-center h-full gap-8 p-8 text-card-foreground">
            <div className="text-4xl font-extrabold tracking-tight text-center">
              Toque para iniciar
            </div>
            <Button onClick={handleStart} size="lg" className="px-12 py-7 text-2xl rounded-xl">
              Iniciar
            </Button>
          </div>
        );

      case "options":
        return (
          <div className="flex flex-col items-center justify-center h-full gap-6 p-8 text-card-foreground">
            <div className="text-3xl font-extrabold tracking-tight text-center mb-4">
              Escolha uma opção
            </div>
            <Button onClick={handlePayment} size="lg" className="w-full py-7 text-2xl rounded-xl">
              💳 Pagamento
            </Button>
            <Button onClick={handleBack} size="lg" variant="secondary" className="w-full py-7 text-2xl rounded-xl">
              ← Voltar
            </Button>
          </div>
        );

      case "payment":
        return (
          <div className="flex flex-col items-center justify-center h-full gap-6 p-8 text-card-foreground">
            <div className="text-7xl mb-4">💳</div>
            <div className="text-3xl font-extrabold tracking-tight text-center">
              Aproxime o cartão no leitor
            </div>
            <div className="text-lg text-center text-muted-foreground mt-4">
              Arraste o cartão roxo até o leitor
            </div>
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mt-6" />
          </div>
        );

      case "processing":
        return (
          <div className="flex flex-col items-center justify-center h-full gap-6 p-8 text-card-foreground">
            <div className="w-20 h-20 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            <div className="text-3xl font-extrabold tracking-tight text-center">
              Processando...
            </div>
          </div>
        );

      case "success":
        return (
          <div className="flex flex-col items-center justify-center h-full gap-6 p-8 text-card-foreground">
            <div className="text-8xl">✅</div>
            <div className="text-3xl font-extrabold tracking-tight text-center">
              Pagamento aprovado!
            </div>
            <Button onClick={handleBack} size="lg" className="mt-4 px-10 py-7 text-2xl rounded-xl">
              Voltar ao início
            </Button>
          </div>
        );
    }
  };

  return (
    <group position={screenPos ?? SCREEN_POS} rotation={screenRot ?? SCREEN_ROT}>
      {/* Screen background plane */}
      <mesh
        onPointerOver={() => setIsHovered(true)}
        onPointerOut={() => setIsHovered(false)}
      >
        <planeGeometry args={screenSize ?? SCREEN_SIZE} />
        <meshStandardMaterial 
          color="hsl(0 0% 100%)" 
          emissive="hsl(0 0% 100%)"
          emissiveIntensity={0.15}
        />
      </mesh>
      
      {/* HTML content overlay */}
      <Html
        transform
        center
        pointerEvents="auto"
        distanceFactor={htmlDistanceFactor ?? HTML_DISTANCE_FACTOR}
        scale={htmlScale ?? HTML_SCALE}
        className="select-none"
        style={{
          width: `${(htmlSize ?? HTML_SIZE)[0]}px`,
          height: `${(htmlSize ?? HTML_SIZE)[1]}px`,
          pointerEvents: "auto",
        }}
        position={[0, 0, 0.01]}
      >
        <div
          className="w-full h-full rounded-xl overflow-hidden bg-card"
          style={{ cursor: isHovered ? "pointer" : "default" }}
        >
          {renderContent()}
        </div>
      </Html>
    </group>
  );
};

export default KioskScreen;
